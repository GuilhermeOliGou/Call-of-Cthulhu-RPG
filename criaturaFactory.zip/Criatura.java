package elementos;

public abstract class Criatura {
    private String nome;
    private double qtdDano;
    
    public String getNome(){
        return nome;
    }
    
    public void setNome(String novoNome){
        nome = novoNome;
    }
    
    public double getQtdDano(){
        return qtdDano;
    }
    
    public void setQtdDano(double dano){
        qtdDano = dano;
    }
    
    public void ataca(){
        System.out.println(getNome() + " atacou voce e causou " + getQtdDano() + " de dano.");
    }
    
    public void surge(){
        System.out.println(getNome() + " esta na sua frente.");
    }
    
    
}
