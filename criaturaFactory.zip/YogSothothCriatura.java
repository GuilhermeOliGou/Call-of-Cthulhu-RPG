package elementos;


public class YogSothothCriatura extends Criatura {
    
    public YogSothothCriatura(){
        setNome("Yog-Sothoth");
        setQtdDano(20.0);
    }
}
