package elementos;

public class NyarlathotepCriatura extends Criatura {
    public NyarlathotepCriatura(){
            setNome("Nyarlathotep");
            setQtdDano(300.0);
    }
}
