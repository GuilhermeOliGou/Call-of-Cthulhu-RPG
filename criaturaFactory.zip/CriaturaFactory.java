package elementos;


public class CriaturaFactory {
    public Criatura criaCriatura(String tipoCriatura){
        if(tipoCriatura.equals("Yog")){
            return new YogSothothCriatura();
        } else if (tipoCriatura.equals("Nya")){
            return new NyarlathotepCriatura();
        } else if(tipoCriatura.equals("Mini")){
            return new MiniYogCriatura();
        } else return null;
    }
}
