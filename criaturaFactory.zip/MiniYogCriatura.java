package elementos;


public class MiniYogCriatura extends YogSothothCriatura {
    public MiniYogCriatura(){
        setNome("Criado de Yog-Sothoth");
        setQtdDano(5.0);
    }
}

