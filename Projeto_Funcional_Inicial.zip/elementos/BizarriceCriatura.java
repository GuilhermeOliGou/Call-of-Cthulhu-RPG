
package elementos;


public enum BizarriceCriatura {
    PADRAO(0),MEDONHA(1),BIZARRA(2),DISFORME(3);
    
    private int tipo;
    BizarriceCriatura(int tipo){
        this.tipo = tipo;
    }
}
