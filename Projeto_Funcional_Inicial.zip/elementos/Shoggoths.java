
package elementos;

public class Shoggoths extends Criatura {
    public Shoggoths(){
        setNome("Shoggoths");
        setVidaMax(126);
        setClassificacao(BizarriceCriatura.DISFORME);
        setQtdDano(1);
    }
}
