package elementos;

public class NyarlathotepCriatura extends Criatura {
    public NyarlathotepCriatura(){
            setNome("Nyarlathotep");
            setVidaMax(100);
            setClassificacao(BizarriceCriatura.MEDONHA);
            setQtdDano(300);
    }
}
