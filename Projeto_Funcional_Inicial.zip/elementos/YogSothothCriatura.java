package elementos;


public class YogSothothCriatura extends Criatura {
    
    public YogSothothCriatura(){
        setNome("Yog-Sothoth");
        setVidaMax(60);
        setClassificacao(BizarriceCriatura.BIZARRA);
        setQtdDano(20);
    }
}
