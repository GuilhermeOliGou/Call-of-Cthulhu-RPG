package elementos;


public class MiniYogCriatura extends YogSothothCriatura {
    public MiniYogCriatura(){
        setNome("Criado de Yog-Sothoth");
        setVidaMax(10);
        setClassificacao(BizarriceCriatura.PADRAO);
        setQtdDano(5);
    }
}

